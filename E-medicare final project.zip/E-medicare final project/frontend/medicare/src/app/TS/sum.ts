export class Sum {
    id:number
}
