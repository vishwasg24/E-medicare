export class Admin {
    id : number;
    name: string;
    password:string;
    contact:number;
}
