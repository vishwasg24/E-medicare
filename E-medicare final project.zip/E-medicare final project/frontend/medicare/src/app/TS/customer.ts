export class Customer {
    id:number;
    name:string;
    password:string;
    contact:number;
    address:string;
}
