package com.medipro.assgn.assgn;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.medipro.assgn.assgn.beans.Product;
import com.medipro.assgn.assgn.controller.CartController;
import com.medipro.assgn.assgn.dao.ProductDaoImpl;

@SpringBootTest
class AssgnApplicationTests {

//	@Test
//	void contextLoads() {
//		
//		 ProductDaoImpl p = new ProductDaoImpl();
//		 Assertions.assertEquals(true,p.listAllPrd());
//		
//	}
	
	
	
	@Test
	public void testForNull()
	{
		String str1 =null;
		String str2 ="abc";
		
		Assertions.assertNull(str1);
		Assertions.assertNotNull(str2);	
	}

}
