package com.medipro.assgn.assgn;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medipro.assgn.assgn.beans.Cart;
import com.medipro.assgn.assgn.beans.Login;
import com.medipro.assgn.assgn.beans.Product;
import com.medipro.assgn.assgn.dao.CartDaoImpl;
import com.medipro.assgn.assgn.dao.LoginDaoImpl;
import com.medipro.assgn.assgn.dao.ProductDaoImpl;

@SpringBootTest
class MediProTest {
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	LoginDaoImpl LoginDao;
	ProductDaoImpl ProductDao;
	CartDaoImpl CartDao;
	
	@Test
	public void getUser(){
		List<Login> list=LoginDao.getUser();
		assertThat(list).size().isGreaterThan(0);
	}
	
	@Test
	public void getUserProfile(){
		List<Login> list=LoginDao.getUserProfile(301);
		assertThat(list).size().isGreaterThan(0);
	}
	
	
	}