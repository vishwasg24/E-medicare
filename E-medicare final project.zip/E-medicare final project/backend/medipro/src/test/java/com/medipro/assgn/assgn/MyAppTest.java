package com.medipro.assgn.assgn;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.medipro.assgn.assgn.beans.Product;
import com.medipro.assgn.assgn.dao.ProductDaoImpl;
import com.medipro.assgn.assgn.service.ProductService;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;


public class MyAppTest 
{

	@Autowired
	ProductService pservice;
	@Test
	@Order(1)
	public void testcreate() 
	{
		Product a = new Product();
		a.setPid(120);
		a.setPname("Master");
		a.setPqty(10);
		a.setPrice(30);
		a.setPtype("Antibiotic");
		a.setStatus("A");
		pservice.addProduct(a);


	}

	@Test
	@Order(2)
	public void testReadAll() {
		List<Product> list = pservice.listAllPrd();
		assertThat(list).size().isGreaterThan(0);

	}
}

