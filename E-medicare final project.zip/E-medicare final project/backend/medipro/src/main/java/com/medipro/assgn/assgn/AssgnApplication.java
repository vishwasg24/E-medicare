package com.medipro.assgn.assgn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssgnApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssgnApplication.class, args);
	}

}
